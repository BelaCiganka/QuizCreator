#include "ui/QuizRunnerDialog.hpp"
#include "repositories/QuestionRepository.hpp"
#include "repositories/AnswerRepository.hpp"
#include "repositories/ResultRepository.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QRadioButton>
#include <QCheckBox>
#include <QLineEdit>
#include <QPushButton>
#include <QRandomGenerator>
#include <QMessageBox>
#include <QButtonGroup>

QuizRunnerDialog::QuizRunnerDialog(const User& user,
                                   int quizId,
                                   QuizSelectDialog::Mode mode,
                                   QWidget* parent)
    : QDialog(parent)
    , m_user(user)
    , m_quizId(quizId)
    , m_mode(mode)
{
    setWindowTitle("Quiz in progress");
    resize(700,500);

    loadQuestions();
    if (m_questions.isEmpty()) {
        QMessageBox::information(this,"Empty","No questions in quiz.");
        reject(); return;
    }
    setupUI();
    showCurrentQuestion();
}

// ---------- data load ----------
void QuizRunnerDialog::loadQuestions()
{
    auto qs = QuestionRepository::byQuiz(m_quizId);
    std::shuffle(qs.begin(), qs.end(), *QRandomGenerator::global());

    for (auto& q : qs) {
        // filter by chosen mode
        if (m_mode==QuizSelectDialog::Mode::MultipleChoice && q.type!=QuestionType::MultipleChoice)
            continue;
        if (m_mode==QuizSelectDialog::Mode::TrueFalse      && q.type!=QuestionType::TrueFalse)
            continue;

        SessionQuestion sq;
        sq.q = q;
        sq.answers = AnswerRepository::byQuestion(q.id);

        // if user izabrao Mixed, a pitanje je Short-Answer,
        // pretvori ga u MultipleChoice generišući distractore
        if (m_mode==QuizSelectDialog::Mode::Mixed &&
            q.type==QuestionType::ShortAnswer){
            // napravi 3 random pogrešna odgovora iz drugih short-answer-a
            QString correct = sq.answers.first().text;
            QList<QString> pool;
            for (auto& other : AnswerRepository::byQuestion(q.id)) {
                if (other.text!=correct) pool<<other.text;
            }
            while (pool.size()<3) pool<<("???"); // fallback
            std::shuffle(pool.begin(),pool.end(),*QRandomGenerator::global());
            QList<Answer> mc;
            mc << Answer{ .text = correct, .isCorrect = true };
            for (int i=0;i<3;++i) mc<<Answer{ .text = pool[i], .isCorrect = false };
            std::shuffle(mc.begin(),mc.end(),*QRandomGenerator::global());
            sq.q.type = QuestionType::MultipleChoice;
            sq.answers = mc;
        }
        if (!sq.answers.isEmpty())
            m_questions << sq;
    }
}

// ---------- UI ----------
void QuizRunnerDialog::setupUI()
{
    auto* v = new QVBoxLayout(this);

    m_progressLbl = new QLabel(this);
    v->addWidget(m_progressLbl);

    m_questionLabel = new QLabel(this);
    m_questionLabel->setWordWrap(true);
    m_questionLabel->setStyleSheet("font-weight:bold; font-size:16px");
    v->addWidget(m_questionLabel);

    m_answerWidget = new QWidget(this);
    m_answerLayout = new QVBoxLayout(m_answerWidget);
    v->addWidget(m_answerWidget,1);

    auto* h = new QHBoxLayout();
    m_submitBtn = new QPushButton("Submit", this);
    m_nextBtn   = new QPushButton("Next",   this);
    m_nextBtn->setEnabled(false);
    h->addStretch();
    h->addWidget(m_submitBtn);
    h->addWidget(m_nextBtn);
    v->addLayout(h);

    connect(m_submitBtn,&QPushButton::clicked,this,&QuizRunnerDialog::onSubmit);
    connect(m_nextBtn,  &QPushButton::clicked,this,&QuizRunnerDialog::onNext);
}

// ---------- per-question ----------
void QuizRunnerDialog::showCurrentQuestion()
{
    const auto total = m_questions.size();
    m_progressLbl->setText(
        QString("Question %1 / %2  |  Score: %3")
            .arg(m_currIdx+1).arg(total).arg(m_score));

    // clear previous widgets
    QLayoutItem* item;
    while ((item = m_answerLayout->takeAt(0))) {
        delete item->widget();
        delete item;
    }
    m_radioBtns.clear();
    m_tfChecks.clear();
    m_shortEdit=nullptr;

    SessionQuestion& sq = m_questions[m_currIdx];
    m_questionLabel->setText(sq.q.text);

    switch (sq.q.type) {
    case QuestionType::TrueFalse: {
        auto* g = new QButtonGroup(this);
        for (int i=0;i<sq.answers.size();++i) {
            auto* c = new QRadioButton(sq.answers[i].text, m_answerWidget);
            g->addButton(c,i);
            m_answerLayout->addWidget(c);
            m_radioBtns<<c;
        }
        break;
    }
    case QuestionType::MultipleChoice: {
        auto* g = new QButtonGroup(this);
        for (int i=0;i<sq.answers.size();++i) {
            auto* c = new QRadioButton(sq.answers[i].text, m_answerWidget);
            g->addButton(c,i);
            m_answerLayout->addWidget(c);
            m_radioBtns<<c;
        }
        break;
    }
    case QuestionType::ShortAnswer: {
        m_shortEdit = new QLineEdit(m_answerWidget);
        m_answerLayout->addWidget(m_shortEdit);
        break;
    }
    }

    m_submitBtn->setEnabled(true);
    m_nextBtn->setEnabled(false);
}

bool QuizRunnerDialog::checkAnswer(SessionQuestion& sq)
{
    bool correct = false;
    switch (sq.q.type) {
    case QuestionType::TrueFalse:
    case QuestionType::MultipleChoice: {
        int sel = -1;
        for (int i=0;i<m_radioBtns.size();++i)
            if (m_radioBtns[i]->isChecked()) { sel=i; break; }
        if (sel==-1){ QMessageBox::information(this,"Select","Choose one"); return false; }
        correct = sq.answers[sel].isCorrect;
        break;
    }
    case QuestionType::ShortAnswer: {
        if (!m_shortEdit){ return false; }
        const QString ans = m_shortEdit->text().trimmed();
        if (ans.isEmpty()){ QMessageBox::information(this,"Type","Enter answer"); return false; }
        correct = ans.compare(sq.answers.first().text, Qt::CaseInsensitive)==0;
        break;
    }
    }
    if (correct) ++m_score;
    return true;
}

void QuizRunnerDialog::onSubmit()
{
    SessionQuestion& sq = m_questions[m_currIdx];
    if (!checkAnswer(sq)) return;

    // disable inputs
    for (auto* r : m_radioBtns)  r->setEnabled(false);
    if (m_shortEdit) m_shortEdit->setEnabled(false);
    m_submitBtn->setEnabled(false);
    m_nextBtn->setEnabled(true);

    // color feedback
    QPalette okPal = palette();
    okPal.setColor(QPalette::WindowText, Qt::green);
    QPalette badPal = palette();
    badPal.setColor(QPalette::WindowText, Qt::red);

    switch (sq.q.type) {
    case QuestionType::MultipleChoice:
    case QuestionType::TrueFalse:
        for (int i=0;i<m_radioBtns.size();++i){
            if (sq.answers[i].isCorrect)
                m_radioBtns[i]->setPalette(okPal);
        }
        break;
    case QuestionType::ShortAnswer:
        if (m_shortEdit){
            m_shortEdit->setPalette(
                sq.answers.first().text.compare(m_shortEdit->text(),Qt::CaseInsensitive)==0
                    ? okPal : badPal);
        }
        break;
    }
}

void QuizRunnerDialog::onNext()
{
    ++m_currIdx;
    if (m_currIdx >= m_questions.size()) {
        // finished
        UserResult ur;
        ur.userId = m_user.id;
        ur.quizId = m_quizId;
        ur.total  = m_questions.size();
        ur.score  = m_score;
        ResultRepository::create(ur);

        QMessageBox::information(this,"Done",
                                 QString("Score %1 / %2").arg(m_score).arg(m_questions.size()));
        accept();
        return;
    }
    showCurrentQuestion();
}
