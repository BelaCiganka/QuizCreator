#pragma once

#include <QObject>

namespace Styles {
void applyGlobalStyle(QWidget* root);
}
