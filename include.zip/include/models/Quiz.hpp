#pragma once

#include <QString>

struct Quiz {
    int id = -1;
    QString title;
    QString description;
};
